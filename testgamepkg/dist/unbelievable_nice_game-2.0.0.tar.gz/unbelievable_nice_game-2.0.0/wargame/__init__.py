import sys
import os
current_path = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_path)
