

class GameUnitError:
    def __init__(self):
        self.error = 'some error'
